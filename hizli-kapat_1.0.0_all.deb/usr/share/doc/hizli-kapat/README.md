# Hızlı Kapat

**Pardus 25 GNOME için** bilgisayarı kapatma onay penceresi.

Pardus GNOME'da Alt+F4 yalnızca açık pencereyi kapatır, kapatma menüsünü açmaz.
Hızlı Kapat bu boşluğu doldurur: bir klavye kısayoluyla (varsayılan **Süper+K**)
"Bilgisayarı kapatmak istiyor musunuz?" penceresini açar, onaylarsanız bilgisayarı kapatır.

- Varsayılan düğme **İptal**'dir; yanlışlıkla Enter'a basarsanız bilgisayar kapanmaz.
- Kısayolu tek komutla kurar, çakışma varsa sizi uyarır.
- Python 3 ve GTK3 eksikse otomatik kurulur.

> Yazan: **Süleyman ŞİŞMAN**

## Kurulum

### Yöntem 1: .deb paketi (önerilen)

[Releases](../../releases) sayfasından `hizli-kapat_1.0.0_all.deb` dosyasını indirin, sonra:

```bash
sudo apt install ./hizli-kapat_1.0.0_all.deb
```

`apt`, Python 3 ve GTK3 eksikse bunları Pardus depolarından kendisi indirip kurar.
(İnternet bağlantısı gerekir.)

### Yöntem 2: Betikle kurulum (yönetici gerekmez)

```bash
git clone https://github.com/KULLANICI_ADINIZ/hizli-kapat.git
cd hizli-kapat
./kur.sh
```

Betik önce Python 3 ve GTK3'ün kurulu olup olmadığına bakar, eksikse `sudo apt-get install`
ile kurar. Program `~/.local/bin` altına kurulur ve sonunda Süper+K kısayolunu ekleyip
eklemeyeceğinizi sorar.

## Kısayolu ekleme

.deb ile kurduysanız kısayol otomatik eklenmez (kurulum sırasında ayarlarınıza dokunulmaz).
Bir kez şunu çalıştırın:

```bash
hizli-kapat --kisayol-kur
```

Artık **Süper+K** kapatma penceresini açar. Başka bir tuş için:

```bash
hizli-kapat --kisayol-kur --tus '<Super>j'
```

Seçtiğiniz tuş başka bir GNOME kısayoluyla çakışıyorsa program kısayolu eklemez ve çakışanı
söyler. Mevcut kısayollarınıza dokunmaz.

Kaldırmak için: `hizli-kapat --kisayol-kaldir`

> **Neden Süper+P değil?** GNOME'da Süper+P "ekran değiştirme" (projektör / ikinci monitör)
> kısayoludur. Başka bir işleme atanırsa çalışmaz. Süper+K varsayılan GNOME'da boştur.

## Kullanım

| Komut | Ne yapar |
|---|---|
| `hizli-kapat` | Onay penceresini açar; "Kapat"a basılırsa bilgisayarı kapatır |
| `hizli-kapat --deneme` | Pencereyi açar ama bilgisayarı **kapatmaz** (deneme için) |
| `hizli-kapat --kisayol-kur [--tus TUŞ]` | Klavye kısayolunu ekler |
| `hizli-kapat --kisayol-kaldir` | Kısayolu kaldırır |
| `hizli-kapat --hakkinda` | Hakkında penceresi |
| `hizli-kapat --surum` | Sürüm bilgisi |

Uygulama menüsünde de **Hızlı Kapat** olarak görünür.

Kapatma için önce `systemctl poweroff`, olmazsa `gnome-session-quit --power-off --no-prompt`
çalıştırılır. İkisi de başarısız olursa hata penceresi gösterilir.

## Kaldırma

```bash
hizli-kapat --kisayol-kaldir        # önce kısayolu kaldırın
sudo apt remove hizli-kapat         # .deb ile kurduysanız
./kaldir.sh                         # kur.sh ile kurduysanız
```

## Gereksinimler ve test durumu

- Pardus 25 GNOME (Wayland oturumunda denenmiştir)
- Python 3, `python3-gi`, `gir1.2-gtk-3.0` (Pardus 25 GNOME'da hazır gelir; eksikse kurulum
  sırasında otomatik eklenir)

Başka bir masaüstünde (ör. Pardus XFCE) onay penceresi çalışır, ancak `--kisayol-kur` yalnızca
GNOME içindir. Orada klavye ayarlarından `hizli-kapat` komutunu elle bir tuşa atayabilirsiniz.

## Geliştirme

```bash
python3 -m unittest discover -s tests -v   # testler (gerçek ayarlarınıza dokunmaz)
./paketle.sh                               # dist/ altında .deb üretir
```

## Lisans

MIT. Ayrıntı için [LICENSE](LICENSE) dosyasına bakın. © 2026 Süleyman ŞİŞMAN
